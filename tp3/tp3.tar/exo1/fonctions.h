#ifndef __FONCTIONS_H__
#define __FONCTIONS_H__

void afficherNotes(float tab[] , int n);
float minimumNote(float tab[], int n);
float maximumNote(float tab[], int n);
float calculeVariance(float tab[], int n);
int rechercheValeur(float tab[], int n, float note);
#endif

