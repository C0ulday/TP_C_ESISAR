#include <stdio.h>
#include "fonctions.h"
#include "histo.h"

int main(void){

    float tab[] = {0 , 13.5 , 8.5 , 13.7 , 20 , 12 , 8.5 , 17 , 11 , 10 , 9.5 , 4 , 14 , 13.5 , 12 , 1 , 15 , 10.5 , 7.5 , 9.5};
    
    /*float tab[5] = {12,13.5,8.5,14.7,6};
    printf("Affichage de notes :\n");
    afficherNotes(tab,5); 

    printf("Note minime :\n");
    printf("%f",minimumNote(tab,5)); //6.00

    printf("Note max :\n");
    printf("%f",maximumNote(tab,5)); //14.70

    printf("Affichage de variance :\n");
    printf("%f",calculeVariance(tab, 5)); //10.434400
    printf("\n");
    printf("Affichage de recherche valeur:\n");
    printf("%d",rechercheValeur(tab,5,6)); //4
    */
    
    //histoHori(tab,20);
    //histoVerti(tab,20);

    return 0;
}