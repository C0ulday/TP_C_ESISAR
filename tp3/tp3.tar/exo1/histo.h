#ifndef __HORI__
#define __HORI__

void histoHori(float tab[], int n);

#endif // !__HORI__


