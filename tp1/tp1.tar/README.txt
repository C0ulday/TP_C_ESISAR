TP1 : Ecriture, compilation et exécution de programmes C simples
CS 357 - COULIBALY Kagnon (Sita)

Objectifs :
# Découvrir la syntaxe et la sémantique du langage C.
# Etre capable d’écrire en C un algorithme simple.


Le Makefile crée les excécutables pour chaque fichier, individuellement.