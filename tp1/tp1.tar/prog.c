#include <stdio.h>

/*Mon premier pogramme C*/
int main(){
    printf("Bonjour ! \n");
    return 0;
}       