La fonction main utlise 2 arguments : des mots
pour le test, lors de la compilation