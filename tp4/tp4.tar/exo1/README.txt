Dans exo1. Manipulation de fichier et tri de tableau
La fonction main focntionne avec 2 arguments que sont :
donnes.txt et sortie.txt