#ifndef __FONCTIONS_H__
#define __FONCTIONS_H__


#define N 30

int lireDonnees(char nomFichier[], int T[]);
void afficherTableau(int T[], int nb);
void triABulles(int T[], int nb);
void enregistrementDonnes(char fichier[], int T[], int nb);

#endif